package com.conecsa.conecsa_backend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ConecsaBackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
